-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Dim 14 Décembre 2014 à 07:47
-- Version du serveur: 5.5.40-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.5

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `sf_eval`
--

--
-- Vider la table avant d'insérer `course`
--

TRUNCATE TABLE `course`;
--
-- Contenu de la table `course`
--

INSERT INTO `course` (`id`, `levels_scale_id`, `name`, `full_name`, `description`, `coefficient`, `position`, `created_at`, `updated_at`) VALUES
(1, 1, 'Prog Web', 'Programmation Web', 'Bla bla bla...', 3, 0, '2014-12-12 14:37:41', '2014-12-14 07:38:34'),
(2, 1, 'Techno Web', 'Technologies Web, Outils et Méthodes', 'Bla bla bla...', 2, 1, '2014-12-13 16:17:50', '2014-12-13 17:43:58');

--
-- Vider la table avant d'insérer `course_degree`
--

TRUNCATE TABLE `course_degree`;
--
-- Contenu de la table `course_degree`
--

INSERT INTO `course_degree` (`course_id`, `degree_id`) VALUES
(1, 4),
(2, 5);

--
-- Vider la table avant d'insérer `criterion`
--

TRUNCATE TABLE `criterion`;
--
-- Contenu de la table `criterion`
--

INSERT INTO `criterion` (`id`, `name`, `description`, `position`, `created_at`, `updated_at`) VALUES
(1, 'Esprit d’analyse', 'Bla bla bla...', 0, '2014-12-12 14:29:31', '2014-12-12 14:29:31'),
(2, 'Niveau technique', 'Bla bla bla...', 1, '2014-12-12 14:29:58', '2014-12-12 14:29:58'),
(3, 'Qualité des réalisations', 'Bla bla bla...', 2, '2014-12-12 14:30:21', '2014-12-12 14:30:21'),
(4, 'Prise en compte des contraintes', 'Bla bla bla...', 3, '2014-12-12 14:30:49', '2014-12-12 14:30:49'),
(5, 'Organisation et gestion du temps', 'Bla bla bla...', 4, '2014-12-12 14:31:13', '2014-12-12 14:31:13');

--
-- Vider la table avant d'insérer `criterion_course`
--

TRUNCATE TABLE `criterion_course`;
--
-- Contenu de la table `criterion_course`
--

INSERT INTO `criterion_course` (`criterion_id`, `course_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2);

--
-- Vider la table avant d'insérer `degree`
--

TRUNCATE TABLE `degree`;
--
-- Contenu de la table `degree`
--

INSERT INTO `degree` (`id`, `name`, `level`, `created_at`, `updated_at`) VALUES
(1, 'Bac+1', 1, '2014-12-12 14:00:07', '2014-12-12 14:05:06'),
(2, 'Bac+2', 2, '2014-12-12 14:00:21', '2014-12-12 14:05:17'),
(3, 'Bac+3', 3, '2014-12-12 14:00:40', '2014-12-12 14:05:27'),
(4, 'Bac+4', 4, '2014-12-12 14:00:59', '2014-12-12 14:05:37'),
(5, 'Bac+5', 5, '2014-12-12 14:01:21', '2014-12-12 14:05:48');

--
-- Vider la table avant d'insérer `examination_session`
--

TRUNCATE TABLE `examination_session`;
--
-- Contenu de la table `examination_session`
--

INSERT INTO `examination_session` (`id`, `period_id`, `student_class_course_id`, `title`, `description`, `coefficient`, `created_at`, `updated_at`) VALUES
(8, 1, 1, 'Devoir n°8', 'Bla bla bla...', 2, '2014-12-13 09:40:20', '2014-12-13 09:40:20');

--
-- Vider la table avant d'insérer `grading`
--

TRUNCATE TABLE `grading`;
--
-- Contenu de la table `grading`
--

INSERT INTO `grading` (`id`, `examination_session_id`, `user_id`, `comment`, `created_at`, `updated_at`) VALUES
(7, 8, 1, 'A touché le fond et creuse encore...', '2014-12-13 09:40:20', '2014-12-13 10:56:58');

--
-- Vider la table avant d'insérer `grading_detail`
--

TRUNCATE TABLE `grading_detail`;
--
-- Contenu de la table `grading_detail`
--

INSERT INTO `grading_detail` (`id`, `criterion_id`, `grading_id`, `percentage`) VALUES
(1, 1, 7, 75.00),
(2, 2, 7, 50.00),
(3, 3, 7, 10.00),
(4, 4, 7, 62.50),
(5, 5, 7, 22.00);

--
-- Vider la table avant d'insérer `level`
--

TRUNCATE TABLE `level`;
--
-- Contenu de la table `level`
--

INSERT INTO `level` (`id`, `level_scale_id`, `name`, `name_abbrev`, `position`, `created_at`, `updated_at`) VALUES
(1, 1, 'Mal acquis (apprentissage erroné)', 'M/A', 0, '2014-12-12 14:33:40', '2014-12-12 14:33:40'),
(2, 1, 'Non encore acquis', 'N/A', 1, '2014-12-12 14:34:22', '2014-12-12 14:34:22'),
(3, 1, 'En voie d’acquisition (apprentissage)', 'E/A', 2, '2014-12-12 14:34:51', '2014-12-12 14:34:51'),
(4, 1, 'Acquis (maîtrise)', 'A', 3, '2014-12-12 14:35:33', '2014-12-12 14:35:33'),
(5, 1, 'Acquis et dépassé (expertise)', 'A/D', 4, '2014-12-12 14:35:59', '2014-12-12 14:35:59');

--
-- Vider la table avant d'insérer `levels_scale`
--

TRUNCATE TABLE `levels_scale`;
--
-- Contenu de la table `levels_scale`
--

INSERT INTO `levels_scale` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Standard', 'Bla bla bla...', '2014-12-12 14:31:55', '2014-12-12 14:31:55');

--
-- Vider la table avant d'insérer `period`
--

TRUNCATE TABLE `period`;
--
-- Contenu de la table `period`
--

INSERT INTO `period` (`id`, `name`, `name_abbrev`, `slug`, `start_at`, `end_at`, `created_at`, `updated_at`) VALUES
(1, 'Semestre 1', 'S1', 'semestre-1', '2014-09-01 00:00:00', '2009-12-31 00:00:00', '2014-12-12 13:58:17', '2014-12-12 13:58:17'),
(2, 'Semestre 2', 'S2', 'semestre-2', '2015-01-01 00:00:00', '2015-06-30 00:00:00', '2014-12-12 13:59:02', '2014-12-12 13:59:02');

--
-- Vider la table avant d'insérer `sex`
--

TRUNCATE TABLE `sex`;
--
-- Contenu de la table `sex`
--

INSERT INTO `sex` (`id`, `gender`, `code`, `title`, `title_abbrev`, `position`) VALUES
(1, 'h', 1, 'Monsieur', 'M.', 0),
(2, 'f', 0, 'Madame', 'Mme', 1);

--
-- Vider la table avant d'insérer `student_class`
--

TRUNCATE TABLE `student_class`;
--
-- Contenu de la table `student_class`
--

INSERT INTO `student_class` (`id`, `degree_id`, `name`, `name_abbrev`, `slug`, `position`, `created_at`, `updated_at`) VALUES
(1, 4, 'Mastère 1 Web', 'M1 Web', 'mastere-1-web', 0, '2014-12-12 14:03:05', '2014-12-13 11:16:03');

--
-- Vider la table avant d'insérer `student_class_course`
--

TRUNCATE TABLE `student_class_course`;
--
-- Contenu de la table `student_class_course`
--

INSERT INTO `student_class_course` (`id`, `course_id`, `student_class_id`, `user_id`, `student_class_coursecol`) VALUES
(1, 1, 1, 2, NULL);

--
-- Vider la table avant d'insérer `user`
--

TRUNCATE TABLE `user`;
--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `student_class_id`, `sex_id`, `first_name`, `last_name`, `slug`, `birth_date`, `about`, `email`, `username`, `password`, `roles`, `is_teacher`, `is_student`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Milan', 'Kundera', 'kundera-milan', '2009-01-08', 'Bla bla bla...', 'kundera@gmail.com', 'kundera', 'kundera', 'Undefined', 0, 1, '2014-12-12 14:09:25', '2014-12-12 14:25:10'),
(2, 1, 1, 'Nicolas', 'Brousse', 'brousse-nicolas', '2009-01-01', 'Bli blo bla...', 'n.brousse@gmail.com', 'broussen', 'broussen', 'Teacher', 1, 1, '2014-12-12 14:27:12', '2014-12-13 11:12:53');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
